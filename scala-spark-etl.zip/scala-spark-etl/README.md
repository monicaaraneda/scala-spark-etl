# scala-spark-etl

Project source code for Monica Araneda Lee's Aparch Spark with Scala Challenge.

https://github.com/maranedaex/scala-spark-etl
