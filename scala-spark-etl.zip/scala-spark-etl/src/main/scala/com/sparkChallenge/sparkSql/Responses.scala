package com.sparkChallenge.sparkSql

case class Responses(metascore: Option[Int],name: String, console: String, userscore: String)
